﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DownloadFileFormatHelper
{
    internal class Program
    {



        static async Task Main(string[] args)
        {
            try
            {

        // 1. 設定 API 位址：使用您指定的 Port 9000 與路徑
                                
                string Url = "http://172.20.0.62:9000/api/parseInDepth";

        // 2. 準備測試資料：使用的Copybook結構
            string CobolCode = @"
               01  TSTBGZ-REC.           
           05  TSTBGZ-YDATE  PIC  X(07).
           05  TSTBGZ-SCURID PIC  X(03).
           05  TSTBGZ-ACTSUB PIC  X(06).
		   05  TSTBGZ-SDAY   PIC  9(03).
           05  TSTBGZ-FXBG1  PIC S9(15)V99.
           05  TSTBGZ-NTBG1  PIC S9(15)V99.
";


        // 3. 執行主程式
        Console.WriteLine($"發送 POST 請求至 {Url}...");

                using var client = new HttpClient();
                // 發送 POST 請求，內容為純文字 COBOL 代碼 (Content-Type: text/plain)
                var content = new StringContent(CobolCode, Encoding.UTF8, "text/plain");
                var response = await client.PostAsync(Url, content);

                // 4. 解析回應
                response.EnsureSuccessStatusCode(); // 確保 HTTP 連線成功 (200 OK)
                string jsonString = await response.Content.ReadAsStringAsync();
                //string jsonString = await response.Content.ReadAsStringAsync();
                System.Diagnostics.Debug.WriteLine(jsonString);
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var resJson = JsonSerializer.Deserialize<ApiResponse>(jsonString, options);

                if (resJson != null && resJson.Success)
                {
                    Console.WriteLine("解析成功，列舉欄位清單：\n");
                    ListItemDetails(resJson.Data);
                }
                else
                {
                    Console.WriteLine($"解析失敗：{resJson?.Error}");
                }

                //程式目的為輸出csv的檔頭和欄位的宣告格式
                //通常應先整理輸出的copybook格式，只輸出選定的欄位
                //故程式只處理第0層和第1層的資料, EX :
                //01  ZACDATE-REC.
                //  05  ZACDATE - KEY             PIC  9(02).
                //  05  ZACDATE - TODAY           PIC  9(07).

                var root = resJson.Data.Where(i => i.Depth == 0).First();
                process(root.Children,root.FieldName.Replace("-REC",""));
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.Print(e.InnerException.ToString());
            Console.WriteLine($"發生錯誤：{e.Message}");
            }
        }

        static void process(List<CopybookItem> fields,string tableName)
        {
            
            string OutputFolder;


            OutputFolder = "D:/";            
            
            string currentTime = System.DateTime.Now.ToString("yyyyMMddhhmmss");

            //string resultFile = "result_" + currentTime + ".txt";
            string resultFile = Path.Combine(OutputFolder, "result_" + currentTime + ".txt");

            StringBuilder sb = new StringBuilder();

            #region 下載格式宣告

            sb.AppendLine("      **************");
            sb.AppendLine("      *下載格式宣告BEGIN");
            sb.AppendLine("      **************");
            sb.AppendLine("       01  CONTROL-REC.");
            sb.AppendLine("           05  FILLER      PIC X(028)");
            sb.AppendLine(@"                           VALUE '@!PP1$ @!L066$ @!C134$ @!R1$'.");
            sb.AppendLine("       01  WORK-REC.");
            sb.AppendLine("           05  SNACTX-CNT              PIC 9(07)  VALUE ZERO.");
            sb.AppendLine("           05  PAGE-CNT                PIC 9(04)  VALUE ZERO.");
            sb.AppendLine("           05  LINE-CNT                PIC 9(04)  VALUE ZERO.");
            sb.AppendLine("       01  TABLE-NAME.");

            int currentIndex = 0;
            foreach (var field in fields)
            {
                sb.AppendLine($"           05  T-{field.FieldName} PIC  X({field.FieldName.Length})  VALUES '{field.FieldName}'.");
                currentIndex++;
                if (currentIndex < fields.Count)
                {
                    sb.AppendLine($"           05  FILLER     PIC  X      VALUE  ','.");
                }
            }

            sb.AppendLine(" ");

            sb.AppendLine("       01  DETAIL-REC.");

            currentIndex = 0;
            foreach (var field in fields)
            {
                currentIndex++;

                if (field.Scale>0) {
                    //此例用 Scale 小數點位數判斷是否為金額欄位
                    //如果是金額欄位先 move 至 edit format ( PIC ---------------9.99.)，故長度取 edit format的長度，為19
                    sb.AppendLine($"           05  D-{field.FieldName} PIC  X(19).");
                }else
                {
                    sb.AppendLine($"           05  D-{field.FieldName} PIC  X({field.StorageLength}).");
                }
                
                if (currentIndex < fields.Count)
                {
                    sb.AppendLine($"           05  FILLER     PIC  X      VALUE  ','.");
                }
            }

            sb.AppendLine($@"       01  PH-REC.
           02  FILLER  PIC  X(3)  VALUE  'D:\'.
           02  PH-1    PIC  X(8).
           02  FILLER  PIC  X(12) VALUE  '-{tableName}.CSV'.

       01  BEGIN-REC.
           05  FILLERX     PIC X(046)  VALUE
               '@!C512$@!PF0000                              $'.
           05  FILLERY REDEFINES FILLERX.
               10  FILLER  PIC X(015).
               10  PATH-NM PIC X(030).
               10  FILLER  PIC X(001).

       01  END-REC.
           05  FILLERX     PIC X(007)
                           VALUE '@!PEND$'. ");
            sb.AppendLine($@"      **************
      *下載格式宣告END
      ************** ");

            #endregion

            #region 產生程式碼

            sb.AppendLine(" ");
            sb.AppendLine(" ");
            sb.AppendLine(" ");

            if(fields.Any(x => x.Scale > 0))
            {
                //csv 檔不能使用 PIC ----,---,---,---,--9.99，因逗號是分隔符號，除非兩邊加上雙引號
                sb.AppendLine($@"       77  WK-EDT-AMT                    PIC ---------------9.99.");
            }
            sb.AppendLine(" ");
            sb.AppendLine(" ");

            sb.AppendLine($@"       WRT-PRT-RTN.
           READ {tableName} NEXT RECORD AT END
           MOVE    ""Y""    TO   END-FLAG
           GO TO   WRT-PRT-RTN-EXIT.

      *FILTER
           IF    (IKEY OF AMAP-I  NOT  =  SPACE   AND  ZEROS)   AND
                 (IKEY OF AMAP-I  NOT  =  {tableName}-KEY)
                 GO  TO   WRT-PRT-RTN-EXIT.

           INITIALIZE        DETAIL-REC.");


            foreach (var field in fields)
            {
                if (field.Scale > 0)
                {
                    sb.AppendLine($"");
                    sb.AppendLine($"           MOVE  {field.FieldName.PadRight(18)}     TO WK-EDT-AMT.");
                    sb.AppendLine($"           MOVE  {"WK-EDT-AMT".PadRight(18)}     TO D-{field.FieldName}.");
                }
                else
                {
                    sb.AppendLine($"");
                    sb.AppendLine($"           MOVE  {field.FieldName.PadRight(18)}     TO D-{field.FieldName}.");
                }

            }

            sb.AppendLine($" ");
            sb.AppendLine(@$"           WRITE   PRINT-REC     FROM  DETAIL-REC.

       WRT-PRT-RTN-EXIT.
           EXIT.   ");

            #endregion

            File.WriteAllText(resultFile, sb.ToString());

            Console.WriteLine("檔案已產生: " + resultFile);
            Console.Read();

            System.Diagnostics.Debug.Print(sb.ToString());

        }

        /// <summary>
        /// 遞迴函式：遍歷樹狀結構並列印所有 IItem 欄位資訊
        /// </summary>
        static void ListItemDetails(List<CopybookItem> items, int currentDepth = 0)
        {
            if (items == null) return;

            foreach (var item in items)
            {
                // 輸出結果：展示階層與關鍵資訊
                string indent = new string(' ', item.Depth * 2);
                Console.WriteLine($"{indent}[{item.LevelString}] {item.FieldName} (Pos: {item.Position}-{item.EndPosition}, Len: {item.TotalStorageLength})");
                Console.WriteLine($"{indent}    > Depth: {item.Depth}, Redefines: {item.RedefinesFieldName}, Redefined: {item.IsFieldRedefined}");
                Console.WriteLine($"{indent}    > Usage: {item.Usage}, Picture: {item.Picture}, InheritedUsage: {item.IsInheritedUsage}");

                // 如果有子項目，遞迴列舉 _children
                if (item.Children != null && item.Children.Count > 0)
                {
                    ListItemDetails(item.Children);
                }
            }
        }


    }

    // --- 資料結構定義 (保留原始註釋) ---

    public class ApiResponse
    {
        public bool Success { get; set; }
        public string Error { get; set; }
        public List<CopybookItem> Data { get; set; }
    }

    public class CopybookItem
    {
        public string LevelString { get; set; }        // 欄位層級字串 (如 "01", "03")
        public int LevelNumber { get; set; }           // 欄位層級數值
        public string FieldName { get; set; }          // 欄位名稱
        public string Picture { get; set; }            // PICTURE 格式遮罩
        public string Usage { get; set; }              // 儲存格式 (USAGE)，如 COMP-3
        public int Position { get; set; }              // 紀錄中的起始位元組位置
        public int EndPosition { get; set; }           // 紀錄中的結束位元組位置
        public int StorageLength { get; set; }         // 單一項目的儲存長度
        public int TotalStorageLength { get; set; }    // 包含重複次數後的總長度

        /// <summary>
        /// 重複次數 (OCCURS) values : {>0 :occurs 次數 ; -1:沒有 occurs}
        /// </summary>
        public int Occurs { get; set; }

        /// <summary>
        /// 最小重複次數 {>0 :OccursMin 次數 ; -1:沒有 OccursMin}
        /// </summary>
        public int OccursMin { get; set; }

        public string RedefinesFieldName { get; set; } // 被重定義的欄位名稱

        /// <summary>
        /// 數值類別代碼 values : { NON_NUMERIC ; NUMERIC_EDITED ; NUMERIC_IN_COBOL}
        /// NUMERIC_EDITED : Numeric edited fields (e.g. -,---,--9.99 are not strictly numeric in Cobol but are often used to send numeric values to non Cobol Systems. So you should consider these fields as numeric
        /// </summary>
        public string NumericClass { get; set; }

        public int Scale { get; set; }                 // 小數位數
        public int DisplayLength { get; set; }         // 顯示長度
        public int DisplayPosition { get; set; }      // 顯示位置
        public string Justified { get; set; }          // 是否對齊 (JUSTIFIED)

        [JsonPropertyName("isSync")]
        public bool IsSync { get; set; }               // 是否同步 (SYNCHRONIZED)

        public string Value { get; set; }              // 初始值或 88 層級的數值
        public string DependingOn { get; set; }        // 依賴欄位 (DEPENDING ON)

        [JsonPropertyName("isFieldRedefined")]
        public bool IsFieldRedefined { get; set; }     // 此欄位是否「被」其他欄位重定義

        [JsonPropertyName("isFieldRedefines")]
        public bool IsFieldRedefines { get; set; }     // 此欄位是否「正在」重定義其他欄位

        public int Depth { get; set; }                 // 結構樹的深度 (0 為最頂層)

        [JsonPropertyName("isInheritedUsage")]
        public bool IsInheritedUsage { get; set; }     // 是否繼承了父層標記的 USAGE 設定

        [JsonPropertyName("isBlankWhenZero")]
        public bool IsBlankWhenZero { get; set; }      // 是否設定為零時顯示空白

        public int RelativeLevel { get; set; }         // 相對層級深度

        /// <summary>
        /// SignClause values : { NO_SIGN_CLAUSE ; <COBOL SIGN CLAUSE> }
        /// </summary>
        public string SignClause { get; set; }

        [JsonPropertyName("_children")]
        public List<CopybookItem> Children { get; set; }
    }
}
